---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304602210087ee2603c3fc48a6d9a4e2196be8512e53329f78a2901b97ff3f28b0ad5cd8e5022100a1f0c5a166352b32370a314243c3984e1698abfe7addf11a7f976444fa74da7f
    ReservedCode2: 3046022100e900f461d7c77af178dfcae3262ab0921f7a7ca8c47f32f27da77c09a9e4a2d8022100cce6c709b0b44cfb066f44e1b3a36f4196a6e5abccf407f15ba01e79995d16ec
---

# Wildberries 评论分析器 - 后端服务配置指南

## 概述

本指南帮助您配置和部署 Wildberries 评论抓取后端服务。该服务使用 Playwright 浏览器自动化技术，支持无限滚动抓取功能。

## 功能特点

- 🔄 **无限滚动抓取**: 自动滚动到页面底部，等待2秒，继续滚动，重复直到无法滚动
- 🌐 **浏览器自动化**: 使用真实浏览器环境，可绕过简单反爬机制
- 📊 **评论解析**: 自动提取评论内容、评分、规格、优缺点等信息
- 🔒 **容错机制**: 抓取失败时自动使用模拟数据

## 环境要求

### 本地开发环境

- Node.js 18+
- npm 或 pnpm
- Docker (可选，用于容器化部署)

### 云端部署环境

- Docker 支持
- 至少 2GB 内存
- 支持容器化部署的平台 (Railway, Render, Fly.io 等)

## 配置步骤

### 方法一：本地开发环境配置

#### 1. 安装依赖

```bash
cd /workspace/wb-review-analyzer

# 安装 Node.js 依赖
npm install

# 或使用 pnpm
pnpm install
```

#### 2. 安装 Playwright 和浏览器

```bash
# 安装 Playwright
npm install playwright

# 安装 Chromium 浏览器
npx playwright install chromium

# 安装 Chromium 系统依赖 (Linux)
npx playwright install-deps chromium
```

#### 3. 启动服务

```bash
# 使用 HTTP API 版本 (轻量级)
node server.js

# 或使用 Playwright 版本 (支持无限滚动)
node server-playwright.js
```

#### 4. 配置环境变量

创建 `.env` 文件:

```env
PORT=3001
NODE_ENV=development
SCROLL_DELAY=2000
MAX_SCROLLS=50
```

### 方法二：Docker 部署

#### 1. 构建 Docker 镜像

```bash
# 使用 Playwright 版本的 Dockerfile
docker build -f Dockerfile.playwright -t wb-scraper .

# 或使用简单版本 (仅 HTTP API)
docker build -t wb-scraper-simple .
```

#### 2. 运行容器

```bash
# 运行容器
docker run -d \
  --name wb-scraper \
  -p 3001:3001 \
  -e PORT=3001 \
  -e SCROLL_DELAY=2000 \
  -e MAX_SCROLLS=50 \
  wb-scraper

# 查看日志
docker logs -f wb-scraper
```

### 方法三：Railway 部署

Railway 是一个支持 Docker 的云部署平台。

#### 1. 准备 Railway 配置

确保项目中有 `railway.json`:

```json
{
  "$schema": "https://railway.app/schema.json",
  "build": {
    "builder": "DOCKERFILE",
    "dockerfilePath": "Dockerfile.playwright"
  },
  "deploy": {
    "numReplicas": 1,
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}
```

#### 2. 部署到 Railway

```bash
# 安装 Railway CLI
npm install -g @railway/cli

# 登录
railway login

# 初始化项目
railway init

# 部署
railway up

# 设置环境变量
railway variables set PORT=3001
railway variables set SCROLL_DELAY=2000
railway variables set MAX_SCROLLS=50
```

#### 3. 获取部署 URL

```bash
railway domain
```

### 方法四：其他云平台部署

#### Render

1. 创建 `render.yaml`:

```yaml
services:
  - type: web
    name: wb-scraper
    env: docker
    dockerfilePath: ./Dockerfile.playwright
    envVars:
      - key: PORT
        value: 3001
      - key: SCROLL_DELAY
        value: 2000
```

2. 连接 GitHub 仓库并部署

#### Fly.io

```bash
# 安装 Fly CLI
curl -L https://fly.io/install.sh | sh

# 登录
fly auth login

# 创建应用
fly launch --image node:18

# 部署
fly deploy -c Dockerfile.playwright
```

## API 使用说明

### 抓取评论

**端点**: `POST /api/scrape`

**请求体**:

```json
{
  "url": "https://www.wildberries.ru/catalog/334228490/feedbacks?imtId=239811658&size=499586675",
  "usePlaywright": true
}
```

**响应**:

```json
{
  "success": true,
  "productId": "334228490",
  "reviews": [
    {
      "id": "review-1",
      "author": "用户名",
      "rating": 5,
      "content": "评论内容...",
      "date": "2024-01-15",
      "specification": "尺寸/颜色",
      "pros": "优点",
      "cons": "缺点"
    }
  ],
  "totalReviews": 30,
  "dataSource": "playwright"
}
```

### 健康检查

**端点**: `GET /api/health`

**响应**:

```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "version": "2.0.0",
  "features": ["playwright", "infinite-scroll"]
}
```

### 服务器状态

**端点**: `GET /api/status`

**响应**:

```json
{
  "status": "running",
  "scrollDelay": 2000,
  "maxScrolls": 50,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

## 环境变量说明

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `PORT` | 3001 | 服务端口 |
| `SCROLL_DELAY` | 2000 | 滚动间隔(毫秒) |
| `MAX_SCROLLS` | 50 | 最大滚动次数 |
| `NODE_ENV` | production | 运行环境 |

## 故障排除

### 常见问题

#### 1. Playwright 浏览器无法启动

**错误**: `Executable doesn't exist`

**解决方案**:

```bash
# 重新安装浏览器
npx playwright install chromium

# 或指定浏览器路径
PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/path/to/chromium node server-playwright.js
```

#### 2. 页面加载超时

**解决方案**:

- 增加超时时间
- 检查网络连接
- 尝试使用 VPN

#### 3. 无法抓取评论数据

**可能原因**:
- Wildberries 网站结构变化
- 反爬机制加强
- 需要登录才能查看评论

**解决方案**:
- 使用模拟数据进行演示
- 手动提取数据并上传 Excel

#### 4. 内存不足

**错误**: `Killed` 或 `out of memory`

**解决方案**:

- 增加容器内存限制
- 减少 `MAX_SCROLLS` 值
- 增加页面清理频率

## 安全建议

1. **不要公开暴露服务**: 使用认证或内部网络
2. **限制请求频率**: 添加速率限制
3. **使用 HTTPS**: 配置 SSL 证书
4. **定期更新**: 保持 Playwright 和依赖最新

## 扩展功能

### 添加代理支持

```javascript
const context = await browser.newContext({
  proxy: {
    server: 'http://your-proxy:8080',
    username: 'user',
    password: 'pass'
  }
});
```

### 添加认证

```javascript
app.post('/api/scrape', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== process.env.API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  // 继续处理...
});
```

### 添加速率限制

```javascript
import rateLimit from('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟
  max: 100 // 每次 IP 最多 100 请求
});

app.use('/api/', limiter);
```

## 技术支持

如有问题，请检查:

1. Docker 日志: `docker logs <container_id>`
2. 服务日志: 查看控制台输出
3. Playwright 状态: `npx playwright test --version`

---

**版本**: 2.0.0
**更新日期**: 2024-01-15
